#!/usr/bin/python3

# COMP3311 24T2 Assignment 2
# Print a list of countries where a named movie was released

import sys
import psycopg2
import helpers

### Globals

db = None
usage = f"Usage: {sys.argv[0]} 'MovieName' Year"

### Command-line args

if len(sys.argv) < 3:
   print(usage)
   exit(1)

# process the command-line args ...

### Queries

### Manipulating database

try:
   db = psycopg2.connect("dbname=ass2")
   # your code goes here

except Exception as err:
   print("DB error: ", err)
finally:
   if db:
      db.close()

